//
//  FollowersTableViewCell.swift
//  Mobile Test
//

import UIKit

class FollowersTableViewCell:UITableViewCell
{
    @IBOutlet var followerImageView:UIImageView!
    @IBOutlet var followerUsernameLabel:UILabel!
}
