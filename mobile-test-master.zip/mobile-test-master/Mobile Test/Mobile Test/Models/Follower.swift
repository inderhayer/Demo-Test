//
//  Follower.swift
//  Mobile Test
//

import UIKit

class Follower:NSObject
{
    var followerImageURL=""
    var followerUsername=""
}
