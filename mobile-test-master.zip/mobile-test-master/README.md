# mobile-test

Xcode Version 10.2.1
Minimum iOS Version 8.0

This application is used for searching Github user by username or email and display all followers of that user.